# Mev-swaps-benefit-
A simple simulation of a sandwich attack bot for the Solana blockchain. This project demonstrates how a searcher might scan pending transactions, identify profitable swaps, and simulate front-running/back-running logic. Built for educational and demonstration purposes.
